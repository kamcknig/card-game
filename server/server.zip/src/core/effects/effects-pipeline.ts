import { GameEffects } from './effect-types/game-effects.ts';
import { AppSocket, EffectHandlerMap, GameEffectGenerator, SourceContext } from '../../types.ts';
import { Match, PlayerId } from 'shared/shared-types.ts';
import { MatchController } from '../match-controller.ts';

export class EffectsPipeline {
  private _prevSnapshot!: Match;
  private _pausedGenerators = new Map<string, {
    generator: GameEffectGenerator;
    source?: SourceContext;
    resolve: (input: unknown) => void;
  }>();
  
  constructor(
    private readonly _effectHandlerMap: EffectHandlerMap,
    private readonly _socketMap: Map<PlayerId, AppSocket>,
    private readonly _effectCompletedCallback: () => void,
    private readonly _matchController: MatchController,
    private readonly _match: Match,
  ) {
  }
  
  public runGenerator(args: {
    generator: GameEffectGenerator,
    source?: SourceContext,
    resumeInput?: unknown,
    resumeSignalId?: string,
    onComplete?: () => void,
  }): unknown {
    this._prevSnapshot = this._matchController.getMatchSnapshot();
    const {
      onComplete,
      resumeInput,
      resumeSignalId,
      generator,
      source
    } = args;
    
    let nextEffect = resumeInput !== undefined && resumeSignalId
      ? generator.next(resumeInput)
      : generator.next();
    
    while (!nextEffect.done) {
      const effect = nextEffect.value as GameEffects;
      const handler = this._effectHandlerMap[effect.type];
      let result: any;
      
      if (!handler) {
        console.warn(`[EFFECT PIPELINE] '${effect.type}' effect handler not found`);
      } else {
        console.log(`[EFFECT PIPELINE] running '${effect.type}' effect`);
        
        result = handler(effect as unknown as any, this._match);
        
        if (result !== undefined) {
          console.log(`[EFFECT PIPELINE] '${effect.type}' effect handler returned:`, result);
          // pauses the current generator, usually to await input from the user
          if ('pause' in result) {
            const { signalId } = result;
            console.log(`[EFFECT PIPELINE] pausing effect '${effect.type}' generator with signal ${signalId}`);
            
            this._pausedGenerators.set(signalId, {
              generator,
              source,
              resolve: (input: unknown) =>
                this.runGenerator({
                  generator,
                  source,
                  resumeInput: input,
                  resumeSignalId: signalId,
                  onComplete
                })
            });
            
            // return because we are 'pausing' the generator
            return result;
          } else if ('runGenerator' in result) {
            this.flushChanges();
            
            // runs a generator returned from the handler
            this.runGenerator({ generator: result.runGenerator, source });
            
            // continue with the outer generator
            nextEffect = generator.next();
            continue;
          }
        }
      }
      
      this.flushChanges();
      nextEffect = generator.next(result);
    }
    
    this.flushChanges();
    onComplete?.();
    this._effectCompletedCallback();
    
    if (!!source && source.type === 'card') {
      this._socketMap.get(source.playerId!)?.emit('cardEffectsComplete', source.playerId, source.cardId);
    }
    
    return nextEffect.value;
  }
  
  public resumeGenerator(signalId: string, userInput: unknown): void {
    console.log(`[EFFECT PIPELINE] resuming generator for signal ${signalId}`);
    const paused = this._pausedGenerators.get(signalId);
    if (!paused) {
      console.log(`[EFFECT PIPELINE] could not find paused generator for signal ${signalId}`);
      return;
    }
    
    this._pausedGenerators.delete(signalId);
    paused.resolve(userInput);
  }
  
  public flushChanges() {
    if (!this._prevSnapshot) return;
    this._matchController.broadcastPatch(this._prevSnapshot);
    this._prevSnapshot = this._matchController.getMatchSnapshot();
  }
}
