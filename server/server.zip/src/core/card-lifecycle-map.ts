import { LifecycleCallbackMap } from '../types.ts';

export const cardLifecycleMap: Record<string, Partial<LifecycleCallbackMap>> =
  {};
